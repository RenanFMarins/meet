require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const sequelize = require('./config/database');
const connectMongoDB = require('./config/mongoDB');
const userRoutes = require('./routes/userRoutes');
const loginRoutes = require('./routes/loginRoutes');
const roomRoutes = require('./routes/roomRoutes');
const homeRoutes = require('./routes/homeRoutes');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

connectMongoDB();

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'templates/pages/login.html'));
  });
app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'templates/pages/home.html'));
});

app.get('/rooms/:id', (req, res) => {
    const roomId = req.params.id;
    res.sendFile(path.join(__dirname, 'templates/pages/room.html'));
});

app.use('/api/register', userRoutes);
app.use('/api/users', userRoutes);
app.use('/api/login', loginRoutes);
app.use('/api/rooms', roomRoutes);
app.use('/api', homeRoutes);

sequelize.authenticate()
  .then(async () => {
    console.log('Conectado ao MySQL!');

    try {
      await sequelize.sync({ force: false });
      console.log('Modelos sincronizados com sucesso!');

      app.listen(PORT, () => {
        console.log(`Servidor rodando na porta ${PORT}`);
      });
    } catch (syncError) {
      console.error('Erro ao sincronizar os modelos:', syncError);
    }
  })
  .catch((err) => {
    console.error('Erro ao conectar ao MySQL:', err);
  });
