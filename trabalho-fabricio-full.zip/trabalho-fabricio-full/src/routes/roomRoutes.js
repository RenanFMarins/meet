const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const Room = require('../models/roomModels');
const { v4: uuidv4 } = require('uuid');
const authMiddleware = require('../middlewares/userMiddleware'); 


router.post('/', authMiddleware, async (req, res) => {
  const { name, description, capacity } = req.body;

  if (!name || !capacity) {
    return res.status(400).json({ message: 'Nome e capacidade são obrigatórios.' });
  }

  try {
    const newRoom = new Room({
      _id: uuidv4(),
      name,
      description,
      capacity,
      is_active: true,
      created_at: new Date()
    });

    await newRoom.save();

    const token = jwt.sign(
      { roomId: newRoom._id, name: newRoom.name },
      process.env.JWT_SECRET,
      { expiresIn: '1h' }
    );

    res.status(201).json({
      message: 'Sala criada com sucesso!',
      room: newRoom,
      token: token
    });

  } catch (error) {
    res.status(500).json({
      message: 'Erro ao criar sala.',
      error: error.message
    });
  }
});

router.get('/', authMiddleware, async (req, res) => {
    try {
      const rooms = await Room.find();
      
      res.status(200).json({
        message: 'Lista de salas recuperada com sucesso!',
        rooms: rooms
      });
    } catch (error) {
      res.status(500).json({
        message: 'Erro ao recuperar a lista de salas.',
        error: error.message
      });
    }
});

router.post('/join', authMiddleware, async (req, res) => {
    const { roomId } = req.body;
  
    if (!roomId) {
      return res.status(400).json({ message: 'roomId é obrigatório.' });
    }
  
    try {
      const room = await Room.findById(roomId);
      if (!room) {
        return res.status(404).json({ message: 'Sala não encontrada.' });
      }
  
      res.status(200).json({
        message: 'Você entrou na sala com sucesso!',
        room: room
      });
    } catch (error) {
      res.status(500).json({
        message: 'Erro ao entrar na sala.',
        error: error.message
      });
    }
  });

module.exports = router;
