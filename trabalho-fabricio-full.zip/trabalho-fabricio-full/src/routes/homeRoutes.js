const express = require('express');
const authMiddleware = require('../middlewares/userMiddleware');

const router = express.Router();

router.get('/home', authMiddleware, (req, res) => {
    res.send({
        message: `Bem-vindo, ${req.user.name}!`,
        token: req.headers.authorization.split(' ')[1],
    });
});

module.exports = router;